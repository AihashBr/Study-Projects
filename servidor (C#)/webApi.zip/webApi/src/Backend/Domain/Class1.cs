﻿namespace Backend.Domain;

public class Class1
{

}
