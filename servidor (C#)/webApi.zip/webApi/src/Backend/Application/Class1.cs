﻿namespace Backend.Application;

public class Class1
{

}
