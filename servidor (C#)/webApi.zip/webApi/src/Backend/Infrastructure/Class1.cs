﻿namespace Backend.Infrastructure;

public class Class1
{

}
